# artificial-intelligence-in-chess-board
algorithm for finding a way from (7,7) to (0,0) in chess board that has some blocked places for pawn and bishop and knight
first you should choose between knight ans pawn and bishop and then chess board will appear 
then you can block every place you want by click on it 
after press statrt button if there is a way to reach the goal it will start to move 
